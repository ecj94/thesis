
/*
			        		although ammap has methos like getAreaCenterLatitude and getAreaCenterLongitude,
			        		they are not suitable in quite a lot of cases as the center of some countries
			        		is even outside the country itself (like US, because of Alaska and Hawaii)
			        		That's why wehave the coordinates stored here
			        	*/

	
			var mapData = [
{  	"code": "AD",
				"name": " AD",
				"latitude": "42.5",
				"longitude": "1.5",
				"value": 2,
				"color": "#a93b38"
			},{  	"code": "AG",
				"name": "Antigua y Barbuda AG",
				"latitude": "17.05",
				"longitude": "-61.8",
				"value": 1,
				"color": "#6b5b2e"
			},{  	"code": "AM",
				"name": "Armenia AM",
				"latitude": "40",
				"longitude": "45",
				"value": 2,
				"color": "#5d5844"
			},{  	"code": "AR",
				"name": "Argentina AR",
				"latitude": "-34",
				"longitude": "-64",
				"value": 179,
				"color": "#a93b38"
			},{  	"code": "AT",
				"name": "Austria AT",
				"latitude": "47.3333",
				"longitude": "13.3333",
				"value": 1,
				"color": "#6b5b2e"
			},{  	"code": "AZ",
				"name": "Azerbaijan AZ",
				"latitude": "40.5",
				"longitude": "47.5",
				"value": 4,
				"color": "#5d5844"
			},{  	"code": "BE",
				"name": "Belgium BE",
				"latitude": "50.8333",
				"longitude": "4",
				"value": 2,
				"color": "#a93b38"
			},{  	"code": "BO",
				"name": "Bolivia BO",
				"latitude": "-17",
				"longitude": "-65",
				"value": 3,
				"color": "#6b5b2e"
			},{  	"code": "BR",
				"name": "Brazil BR",
				"latitude": "-10",
				"longitude": "-55",
				"value": 55,
				"color": "#5d5844"
			},{  	"code": "CA",
				"name": "Canada CA",
				"latitude": "54",
				"longitude": "-100",
				"value": 7,
				"color": "#a93b38"
			},{  	"code": "CG",
				"name": "Congo, Rep. CG",
				"latitude": "-1",
				"longitude": "15",
				"value": 1,
				"color": "#6b5b2e"
			},{  	"code": "CL",
				"name": "Chile CL",
				"latitude": "-30",
				"longitude": "-71",
				"value": 491,
				"color": "#5d5844"
			},{  	"code": "CN",
				"name": "China CN",
				"latitude": "35",
				"longitude": "105",
				"value": 6,
				"color": "#a93b38"
			},{  	"code": "CO",
				"name": "Colombia CO",
				"latitude": "4",
				"longitude": "-72",
				"value": 332,
				"color": "#6b5b2e"
			},{  	"code": "CR",
				"name": "Costa Rica CR",
				"latitude": "10",
				"longitude": "-84",
				"value": 5,
				"color": "#5d5844"
			},{  	"code": "CU",
				"name": "Cuba CU",
				"latitude": "21.5",
				"longitude": "-80",
				"value": 49,
				"color": "#a93b38"
			},{  	"code": "CV",
				"name": "Cape Verde CV",
				"latitude": "16",
				"longitude": "-24",
				"value": 1,
				"color": "#6b5b2e"
			},{  	"code": "CY",
				"name": "Cyprus CY",
				"latitude": "35",
				"longitude": "33",
				"value": 1,
				"color": "#5d5844"
			},{  	"code": "DE",
				"name": "Germany DE",
				"latitude": "51",
				"longitude": "9",
				"value": 13,
				"color": "#a93b38"
			},{  	"code": "DO",
				"name": "Dominican Rep. DO",
				"latitude": "19",
				"longitude": "-70.6667",
				"value": 3,
				"color": "#6b5b2e"
			},{  	"code": "EC",
				"name": "Ecuador EC",
				"latitude": "-2",
				"longitude": "-77.5",
				"value": 42,
				"color": "#5d5844"
			},{  	"code": "EE",
				"name": "Estonia EE",
				"latitude": "59",
				"longitude": "26",
				"value": 1,
				"color": "#a93b38"
			},{  	"code": "ES",
				"name": "Spain ES",
				"latitude": "40",
				"longitude": "-4",
				"value": 1137,
				"color": "#6b5b2e"
			},{  	"code": "FR",
				"name": "France FR",
				"latitude": "46",
				"longitude": "2",
				"value": 11,
				"color": "#5d5844"
			},{  	"code": "GB",
				"name": "United Kingdom GB",
				"latitude": "54",
				"longitude": "-2",
				"value": 13,
				"color": "#a93b38"
			},{  	"code": "HN",
				"name": "Honduras HN",
				"latitude": "15",
				"longitude": "-86.5",
				"value": 1,
				"color": "#6b5b2e"
			},{  	"code": "ID",
				"name": "Indonesia ID",
				"latitude": "-5",
				"longitude": "120",
				"value": 5,
				"color": "#5d5844"
			},{  	"code": "IN",
				"name": "India IN",
				"latitude": "20",
				"longitude": "77",
				"value": 4,
				"color": "#a93b38"
			},{  	"code": "IR",
				"name": "Iran IR",
				"latitude": "32",
				"longitude": "53",
				"value": 7,
				"color": "#6b5b2e"
			},{  	"code": "IT",
				"name": "Italy IT",
				"latitude": "42.8333",
				"longitude": "12.8333",
				"value": 3,
				"color": "#5d5844"
			},{  	"code": "LV",
				"name": "Latvia LV",
				"latitude": "57",
				"longitude": "25",
				"value": 1,
				"color": "#a93b38"
			},{  	"code": "MS",
				"name": "Montserrat MS",
				"latitude": "16.75",
				"longitude": "-62.2",
				"value": 1,
				"color": "#6b5b2e"
			},{  	"code": "MX",
				"name": "Mexico MX",
				"latitude": "23",
				"longitude": "-102",
				"value": 1615,
				"color": "#5d5844"
			},{  	"code": "NI",
				"name": "Nicaragua NI",
				"latitude": "13",
				"longitude": "-85",
				"value": 3,
				"color": "#a93b38"
			},{  	"code": "NL",
				"name": "Netherlands NL",
				"latitude": "52.5",
				"longitude": "5.75",
				"value": 3,
				"color": "#6b5b2e"
			},{  	"code": "NO",
				"name": "Norway NO",
				"latitude": "62",
				"longitude": "10",
				"value": 1,
				"color": "#5d5844"
			},{  	"code": "PE",
				"name": "Peru PE",
				"latitude": "-10",
				"longitude": "-76",
				"value": 35,
				"color": "#a93b38"
			},{  	"code": "PK",
				"name": "Pakistan PK",
				"latitude": "30",
				"longitude": "70",
				"value": 6,
				"color": "#6b5b2e"
			},{  	"code": "PL",
				"name": "Poland PL",
				"latitude": "52",
				"longitude": "20",
				"value": 2,
				"color": "#5d5844"
			},{  	"code": "PR",
				"name": "Puerto Rico PR",
				"latitude": "18.25",
				"longitude": "-66.5",
				"value": 2,
				"color": "#a93b38"
			},{  	"code": "PT",
				"name": "Portugal PT",
				"latitude": "39.5",
				"longitude": "-8",
				"value": 26,
				"color": "#6b5b2e"
			},{  	"code": "RS",
				"name": "Serbia RS",
				"latitude": "44",
				"longitude": "21",
				"value": 3,
				"color": "#5d5844"
			},{  	"code": "RU",
				"name": "Russia RU",
				"latitude": "60",
				"longitude": "100",
				"value": 16,
				"color": "#a93b38"
			},{  	"code": "SE",
				"name": "Sweden SE",
				"latitude": "62",
				"longitude": "15",
				"value": 2,
				"color": "#6b5b2e"
			},{  	"code": "SK",
				"name": "Slovak Republic SK",
				"latitude": "48.6667",
				"longitude": "19.5",
				"value": 1,
				"color": "#5d5844"
			},{  	"code": "TR",
				"name": "Turkey TR",
				"latitude": "39",
				"longitude": "35",
				"value": 7,
				"color": "#a93b38"
			},{  	"code": "US",
				"name": "United States US",
				"latitude": "38",
				"longitude": "-97",
				"value": 28,
				"color": "#6b5b2e"
			},{  	"code": "UY",
				"name": "Uruguay UY",
				"latitude": "-33",
				"longitude": "-56",
				"value": 3,
				"color": "#5d5844"
			},{  	"code": "VE",
				"name": "Venezuela VE",
				"latitude": "8",
				"longitude": "-66",
				"value": 45,
				"color": "#a93b38"
			},{  	"code": "YT",
				"name": "Mayotte YT",
				"latitude": "-12.8333",
				"longitude": "45.1667",
				"value": 2,
				"color": "#6b5b2e"
			},{  	"code": "ZA",
				"name": "South Africa ZA",
				"latitude": "-29",
				"longitude": "24",
				"value": 3,
				"color": "#5d5844"
			}			];


			var map;
			var minBulletSize = 3;
			var maxBulletSize = 20;
			var min = Infinity;
			var max = -Infinity;

			//AmCharts.theme = AmCharts.themes.black;

			// get min and max values
			for (var i = 0; i < mapData.length; i++) {
				var value = mapData[i].value;
				if (value < min) {
					min = value;
				}
				if (value > max) {
					max = value;
				}
			}

			// build map
			AmCharts.ready(function() {
				map = new AmCharts.AmMap();
				map.projection = "winkel3";

				map.addTitle("Procedencia de los autores", 14);
				
				map.areasSettings = {
					unlistedAreasColor: "#000000",
					unlistedAreasAlpha: 0.1
				};
				map.imagesSettings = {
					balloonText: "<span style='font-size:14px;'><b>[[title]]</b>: [[value]]</span>",
					alpha: 0.6
				}

				var dataProvider = {
					mapVar: AmCharts.maps.worldLow,
					images: []
				}

				// create circle for each country

				// it's better to use circle square to show difference between values, not a radius
				var maxSquare = maxBulletSize * maxBulletSize * 2 * Math.PI;
				var minSquare = minBulletSize * minBulletSize * 2 * Math.PI;

				// create circle for each country
				for (var i = 0; i < mapData.length; i++) {
					var dataItem = mapData[i];
					var value = dataItem.value;
					// calculate size of a bubble
					var square = (value - min) / (max - min) * (maxSquare - minSquare) + minSquare;
					if (square < minSquare) {
						square = minSquare;
					}
					var size = Math.sqrt(square / (Math.PI * 2));
					var id = dataItem.code;

					dataProvider.images.push({
						type: "circle",
						width: size,
						height: size,
						color: dataItem.color,
						longitude: dataItem.longitude,
						latitude: dataItem.latitude,
						title: dataItem.name,
						value: value
					});
				}



				// the following code uses circle radius to show the difference
				/*
				for (var i = 0; i < mapData.length; i++) {
					var dataItem = mapData[i];
					var value = dataItem.value;
					// calculate size of a bubble
					var size = (value - min) / (max - min) * (maxBulletSize - minBulletSize) + minBulletSize;
					if (size < minBulletSize) {
						size = minBulletSize;
					}
					var id = dataItem.code;

					dataProvider.images.push({
						type: "circle",
						width: size,
						height: size,
						color: dataItem.color,
						longitude: latlong[id].longitude,
						latitude: latlong[id].latitude,
						title: dataItem.name,
						value: value
					});
				}*/



				map.dataProvider = dataProvider;

				map.write("mapdiv");
			}); 
			
